<br>
<center>
    <!-- Agregar zona -->
<div class="col-md-4" id="zona">
    <div class="card">
        <div class="card-header"><i class="bi bi-person-plus-fill"></i> Inicie sesion</div>
        <div class="card-body">
            <a href="../login.html" class="btn btn-primary">Iniciar sesion</a>
        </div>
    </div>
</div>
</center>