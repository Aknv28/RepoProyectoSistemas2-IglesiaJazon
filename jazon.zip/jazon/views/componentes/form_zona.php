<div class="mb-3">
    <label for="nombre_zona" class="form-label">Nombre de la Zona</label>
    <input type="text" name="nombre_zona" id="nombre_zona" class="form-control" required>
    <small id="error_nombre" class="text-danger"></small>
</div>