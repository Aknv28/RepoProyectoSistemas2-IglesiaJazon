<!-- Sidebar -->
<div class="sidebar">
    <button class="sidebar-toggle" onclick="toggleSidebar()">☰</button>
    <h2 class="text-center text-white">Menú</h2>
    <ul class="nav flex-column">
        <li class="nav-item1"><a href="../index.php" class="nav-link">Inicio</a></li>
        <li class="nav-item1"><a href="index2.php" class="nav-link">Dashboard</a></li>
    </ul>
</div>