<div class="mb-3">
    <label for="nombre" class="form-label">Nombre de la Categoria</label>
    <input type="text" name="nombre" id="nombre" class="form-control" required>
    <small id="error_nombre" class="text-danger"></small>
</div>